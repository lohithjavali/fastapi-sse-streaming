# LLM Streaming Cloud Run Minimal Demo

## Project Structure

llm-stream-demo/
├── backend/
│   ├── app/main.py        # FastAPI SSE endpoint
│   ├── requirements.txt
│   └── Dockerfile
└── frontend/
    └── index.html         # Minimal EventSource HTML/JS frontend

## Deploy Backend to Cloud Run (no extra permissions needed)

# 1. Enable APIs (run once per project)
gcloud services enable run.googleapis.com containerregistry.googleapis.com

# 2. Build backend image
cd backend
docker build -t gcr.io/$PROJECT_ID/llm-stream-demo .

# 3. Push image to Google Container Registry
gcloud auth configure-docker
docker push gcr.io/$PROJECT_ID/llm-stream-demo

# 4. Deploy to Cloud Run:
gcloud run deploy llm-stream-demo   --image gcr.io/$PROJECT_ID/llm-stream-demo   --region us-central1   --platform managed   --allow-unauthenticated   --port 8080

# 5. Get your backend URL:
gcloud run services describe llm-stream-demo --region us-central1 --format "value(status.address.url)"

## Try the Frontend

# 1. Download/copy frontend/index.html
# 2. Open it in a browser.
# 3. In the JS, edit the fetch/EventSource URL to your Cloud Run backend URL.
