from fastapi import FastAPI, Request
from sse_starlette.sse import EventSourceResponse
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/stream-llm")
async def stream_llm(request: Request, prompt: str = "Hello"):
    async def llm_event_gen(prompt: str, request: Request):
        response = f"Simulated LLM response to: '{prompt}'. This stream shows how LLM chunked text flows."
        words = response.split()
        for i, word in enumerate(words):
            if await request.is_disconnected():
                break
            yield {"event": "llm_chunk", "data": word}
            import asyncio
            await asyncio.sleep(0.15)
        yield {"event": "done", "data": "[DONE]"}
    return EventSourceResponse(llm_event_gen(prompt, request))
